<?php /* #?ini charset="iso-8859-1"?
[ExtensionSettings]
DesignExtensions[]=groupdocscomparison

#[StylesheetSettings]
#BackendCSSFileList[]=gdcomparison_ezoe.css

[JavaScriptSettings]
JavaScriptList[]=gdcomparison.js
*/ ?>