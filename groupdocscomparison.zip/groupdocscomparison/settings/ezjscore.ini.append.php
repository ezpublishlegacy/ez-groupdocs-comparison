
[ezjscServer]
FunctionList[]=groupdocscomparison

[ezjscServer_groupdocscomparison]
Class=GroupdocscomparisonServerCallFunctions
File=extension/groupdocscomparison/classes/groupdocscomparisonservercallfunctions.php
//Functions[]=groupdocscomparison
// {*Not a valid ezjscServerRouter argument: &quot;ezjscdemo::search&quot;*}
// {*http://svn.projects.ez.no/ezjscore/trunk/packages/ezjscore_extension/documents/example/ezjscore_demo/FAQ - point 4*}

