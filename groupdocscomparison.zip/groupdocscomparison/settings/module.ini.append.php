<?php /*
[ModuleSettings]
ExtensionRepositories[]=groupdocscomparison
ModuleList[]=groupdocscomparison
*/ ?>